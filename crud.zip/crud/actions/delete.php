<?php
include __DIR__ . '/../config/db.php';
if (isset($_GET['id'])) {
$id = (int)$_GET['id'];
$sql = "DELETE FROM users WHERE id=$id";
mysqli_query($conn, $sql);
}
header('Location: ../views/view.php');
exit;
?>