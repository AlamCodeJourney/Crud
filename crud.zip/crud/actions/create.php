<?php
include __DIR__ . '/../config/db.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$fname = mysqli_real_escape_string($conn, $_POST['fname']);
$lname = mysqli_real_escape_string($conn, $_POST['lname']);
$password = password_hash($_POST['password'], PASSWORD_DEFAULT); // store hashed password
$gender = mysqli_real_escape_string($conn, $_POST['gender']);
$email = mysqli_real_escape_string($conn, $_POST['email']);
$phone = mysqli_real_escape_string($conn, $_POST['phone']);
$address = mysqli_real_escape_string($conn, $_POST['address']);


// Check duplicate email
$check = mysqli_query($conn, "SELECT id FROM users WHERE email='$email'");
if (mysqli_num_rows($check) > 0) {
header('Location: ../views/index.php?error=Email already exists');
exit;
}


$sql = "INSERT INTO users (fname,lname,password,gender,email,phone,address) VALUES ('$fname','$lname','$password','$gender','$email','$phone','$address')";
if (mysqli_query($conn, $sql)) {
header('Location: ../views/view.php?success=created');
exit;
} else {
header('Location: ../views/index.php?error=' . urlencode(mysqli_error($conn)));
exit;
}
}
?>