<?php
include __DIR__ . '/../config/db.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$id = (int)$_POST['id'];
$fname = mysqli_real_escape_string($conn, $_POST['fname']);
$lname = mysqli_real_escape_string($conn, $_POST['lname']);
$gender = mysqli_real_escape_string($conn, $_POST['gender']);
$email = mysqli_real_escape_string($conn, $_POST['email']);
$phone = mysqli_real_escape_string($conn, $_POST['phone']);
$address = mysqli_real_escape_string($conn, $_POST['address']);


// If password field not empty, update password
if (!empty($_POST['password'])) {
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
$sql = "UPDATE users SET fname='$fname', lname='$lname', password='$password', gender='$gender', email='$email', phone='$phone', address='$address' WHERE id=$id";
} else {
$sql = "UPDATE users SET fname='$fname', lname='$lname', gender='$gender', email='$email', phone='$phone', address='$address' WHERE id=$id";
}


if (mysqli_query($conn, $sql)) {
header('Location: ../views/view.php?success=updated');
exit;
} else {
header('Location: ../views/edit.php?id=' . $id . '&error=' . urlencode(mysqli_error($conn)));
exit;
}
}
?>