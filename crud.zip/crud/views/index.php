<?php // Registration form --> points to actions/create.php ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Register</title>
<link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div class="container">
<h2>REGISTRATION FORM</h2>
<?php if(isset($_GET['error'])): ?>
<div class="alert error"><?php echo htmlspecialchars($_GET['error']); ?></div>
<?php endif; ?>


<form action="../actions/create.php" method="POST" id="regForm">
<label>First Name</label>
<input type="text" name="fname" required>


<label>Last Name</label>
<input type="text" name="lname" required>


<label>Password</label>
<input type="password" name="password" id="password" required>


<label>Confirm Password</label>
<input type="password" name="cpassword" id="cpassword" required>


<label>Gender</label>
<select name="gender" required>
<option value="">Select</option>
<option value="Male">Male</option>
<option value="Female">Female</option>
<option value="Other">Other</option>
</select>


<label>Email Address</label>
<input type="email" name="email" required>


<label>Phone Number</label>
<input type="text" name="phone" required>


<label>Address</label>
<textarea name="address" required></textarea>


<div class="checkbox">
<input type="checkbox" id="agree" required> <label for="agree">Agree to terms and conditions</label>
</div>


<button class="btn" type="submit">Register</button>
</form>


<!--footer-->
<footer style="text-align:center; padding:15px; font-size:14px; color:#6a0dad;">
    <span style="font-size:18px;">©</span> 2025 AlamCodeJourney  
    <br> Made with ❤️ by Pravej Alam
</footer>



<script src="../assets/script.js"></script>
</body>
</html>