<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Users</title>

    <style>

        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background: #d77be5;
        }

        .wrapper {
            max-width: 900px;
            margin: 40px auto;
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 0 10px rgba(0,0,0,0.2);
        }

        h2 {
            text-align: center;
            color: #b448d1;
            margin-bottom: 25px;
        }

        .add-btn {
            display: inline-block;
            background: #d77be5;
            padding: 10px 20px;
            color: white;
            border-radius: 8px;
            text-decoration: none;
            margin-bottom: 15px;
            font-weight: bold;
        }

        .msg {
            background: #d6ffd6;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            color: green;
            font-weight: bold;
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        table th, table td {
            border: 1px solid #ccc;
            padding: 12px;
            text-align: center;
        }

        table th {
            background: #efc5ff;
            color: #7a1693;
            font-weight: bold;
        }

        table tr:nth-child(even) {
            background: #faf2ff;
        }

        a.action-link {
            color: #7a1693;
            text-decoration: none;
            font-weight: bold;
        }

        a.action-link:hover {
            text-decoration: underline;
        }

        /* Responsive Table */
        @media screen and (max-width: 600px) {
            table, thead, tbody, th, td, tr {
                display: block;
            }

            tr {
                margin-bottom: 15px;
            }

            td {
                text-align: right;
                padding-left: 50%;
                position: relative;
            }

            td::before {
                content: attr(data-label);
                position: absolute;
                left: 10px;
                text-align: left;
                font-weight: bold;
            }
        }

    </style>

</head>
<body>

<div class="wrapper">

    <h2>All Users</h2>

    <a href="index.php" class="add-btn">Add New</a>

    <?php if(isset($_GET['success'])) { ?>
        <div class="msg">Created successfully!</div>
    <?php } ?>

    <table>
        <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Gender</th>
            <th>Address</th>
            <th>Actions</th>
        </tr>
        </thead>

        <tbody>

        <?php
        include "../config/db.php";
        $result = mysqli_query($conn, "SELECT * FROM users ORDER BY id DESC");

        while($row = mysqli_fetch_assoc($result)) {
        ?>

            <tr>
                <td data-label="ID"><?= $row['id'] ?></td>
                <td data-label="Name"><?= $row['fname'] . " " . $row['lname'] ?></td>
                <td data-label="Email"><?= $row['email'] ?></td>
                <td data-label="Phone"><?= $row['phone'] ?></td>
                <td data-label="Gender"><?= $row['gender'] ?></td>
                <td data-label="Address"><?= $row['address'] ?></td>
                <td data-label="Actions">
                    <a class="action-link" href="edit.php?id=<?= $row['id'] ?>">Edit</a> |
                    <a class="action-link" href="../actions/delete.php?id=<?= $row['id'] ?>">Delete</a>
                </td>
            </tr>

        <?php } ?>

        </tbody>
    </table>

</div>

</body>
</html>
