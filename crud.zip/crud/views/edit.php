<?php include __DIR__ . '/../config/db.php';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$res = mysqli_query($conn, "SELECT * FROM users WHERE id=$id");
$row = mysqli_fetch_assoc($res);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Edit User</title>
<link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div class="container">
<h2>Edit User</h2>
<?php if(!$row) { echo '<div class="alert error">User not found</div>'; } else { ?>
<form action="../actions/update.php" method="POST">
<input type="hidden" name="id" value="<?php echo $row['id']; ?>">


<label>First Name</label>
<input type="text" name="fname" value="<?php echo htmlspecialchars($row['fname']); ?>" required>


<label>Last Name</label>
<input type="text" name="lname" value="<?php echo htmlspecialchars($row['lname']); ?>" required>


<label>Password <small>(leave blank to keep existing)</small></label>
<input type="password" name="password">


<label>Gender</label>
<select name="gender" required>
<option value="">Select</option>
<option value="Male" <?php if($row['gender']=='Male') echo 'selected'; ?>>Male</option>
<option value="Female" <?php if($row['gender']=='Female') echo 'selected'; ?>>Female</option>
<option value="Other" <?php if($row['gender']=='Other') echo 'selected'; ?>>Other</option>
</select>


<label>Email Address</label>
<input type="email" name="email" value="<?php echo htmlspecialchars($row['email']); ?>" required>


<label>Phone Number</label>
<input type="text" name="phone" value="<?php echo htmlspecialchars($row['phone']); ?>" required>


<label>Address</label>
<textarea name="address" required><?php echo htmlspecialchars($row['address']); ?></textarea>


<button class="btn" type="submit">Update</button>
</form>
<?php } ?>
</div>
</body>
</html>