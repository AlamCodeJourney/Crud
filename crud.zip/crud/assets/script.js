// Basic client-side validation (confirm password)
document.addEventListener('DOMContentLoaded', function(){
var form = document.getElementById('regForm');
if (!form) return;
form.addEventListener('submit', function(e){
var p = document.getElementById('password').value;
var cp = document.getElementById('cpassword').value;
if (p !== cp) {
e.preventDefault();
alert('Password and Confirm Password do not match');
return false;
}
});
});